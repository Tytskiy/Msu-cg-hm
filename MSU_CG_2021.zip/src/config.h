#ifndef MAIN_CONFIG_H
#define MAIN_CONFIG_H

static constexpr int TILE_SIZE = 24;
static constexpr int PADDING = 5;
#endif //MAIN_CONFIG_H
